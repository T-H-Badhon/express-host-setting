const { createServer } = require('http');

const dev = process.env.NODE_ENV !== 'production';
const port = !dev ? process.env.PORT : 3000;

// We'll import the compiled JavaScript version of our Express app
const expressApp = require('./dist/server').default;

const server = createServer((req, res) => {
  console.log(`Request received: ${req.method} ${req.url}`);
  
  // Pass the request to the Express app
  expressApp(req, res);
});

server.listen(port, (err) => {
  if (err) throw err;
  console.log(`> Server ready on http://localhost:${port}`);
});

